package com.jsoup;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


/**
 * Created by Administrator on 2015/10/21.
 */
public class ObtainInfo {
    public Document doc;
    private Elements elements;


    public ObtainInfo() throws Exception {

        doc = Jsoup.connect
                ("http://staff.whu.edu.cn/show.jsp?n=Ai%20Xin%20Ping&lang=cn").get();
    }

    public String getInfoByTag(String str) {
        elements = doc.getElementsByTag(str);
        String temp = elements.toString();
        return temp;
    }

    public String getInfoByClass(String str) {
        elements = doc.getElementsByClass(str);
        String temp = elements.toString();
        return temp;
    }


}
