package com.jsoup;

import java.io.*;
import java.util.Arrays;

import java.util.List;

public class Main2014302580011 {

    public static void main(String[] args) throws Exception {

        //生成两个对象
        ObtainInfo Info = new ObtainInfo();
        ListSolution solution = new ListSolution();

        //首先获取教师名字
        String Name = Info.getInfoByClass("title");
        String[] NameString = Name.split("");
        List<String> tempList = solution.transformArrayToList(NameString);
        List<String> NameList = solution.deleteTag(tempList);
        String name = "";
        for (int i = 1; i < 4; i++) {
            name += NameList.get(i);
        }
        solution.Initialize();

        //将网页中所有p标签的内容都放到一个线性表里
        //TeacherInfo里存的是所有的教师信息
        String TagP = Info.getInfoByTag("p");
        String[] s1 = TagP.split("");
        String[] s2 = TagP.split(" ");
        List<String> list = solution.transformArrayToList(s1);
        List<String> TeacherInfo = solution.deleteTag(list);

        String Information = "";
        for (int i = 0; i < TeacherInfo.size(); i++) {
            Information += TeacherInfo.get(i);
        }
        String[] InformationArray = Information.split(" ");


        //这里是通过正则表达式获取邮箱和电话的代码
        List<String> anotherList = Arrays.asList(s2);
        String Email = solution.getEmail(anotherList);
        String PhoneNumber = solution.getPhoneNumber(anotherList);

        //下面开始输出到txt文件里
        File file = new File("Output.txt");
        file.createNewFile();
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        OutputStreamWriter outputStreamWriter =
                new OutputStreamWriter(fileOutputStream, "UTF-8");
        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
        bufferedWriter.write("姓名： " + name);
        bufferedWriter.newLine();
        bufferedWriter.write("邮箱： " + Email);
        bufferedWriter.newLine();
        bufferedWriter.write("电话号码： " + PhoneNumber);
        bufferedWriter.newLine();
        bufferedWriter.write("其它信息： " + InformationArray[InformationArray.length - 1]);
        bufferedWriter.close();
        outputStreamWriter.close();
        fileOutputStream.close();

    }

}
