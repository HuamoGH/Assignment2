package com.jsoup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2015/10/21.
 */
public class ListSolution {
    private List<String> ArrayList = new ArrayList<>();
    private List<String> List = new ArrayList<>();
    private String emailRegex = "\\w+@\\w+(\\.\\w{2,3})*\\.\\w{2,3}";
    private String phoneRegex = "\\d{11}";
    private String s = new String();

    public String getEmail(List<String> list){
        for (int i = 0;i<list.size();i++){
            if (list.get(i).matches(emailRegex)){
                s = list.get(i);
            }

        }
        return s;
    }

    public String getPhoneNumber(List<String> list){
        for (int i = 0;i<list.size();i++){
            if (list.get(i).matches(phoneRegex)){
                s = list.get(i);
            }

        }
        return s;
    }

    public List<String> transformArrayToList(String[] s) {
        List = Arrays.asList(s);
        return List;
    }

    public List<String> deleteTag(List<String> list) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).equals(">")) {
                for (int j = i; j < list.size(); j++) {
                    if (list.get(j).equals("<")) {
                        break;
                    } else if (list.get(j).equals(">")) {
                    } else {
                        ArrayList.add(list.get(j));
                    }
                }
            }
        }
        return ArrayList;
    }

    public void OutputList(List<String> list) {
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i));
        }
    }

    public void Initialize(){
        ArrayList.clear();
    }
}
